package com.jeet.upi

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ParserTest {
    @Test fun sbi() { val c = Parser.parse("Dear UPI user A/C X1234 credited by Rs560.00 on date 28Oct26 trf to RAMESH KUMAR Refno 430212345678. -SBI")!!; assertEquals(560.0, c.amt, 0.001); assertEquals("430212345678", c.utr) }
    @Test fun hdfc() { val c = Parser.parse("Money Received - INR 560.00 in your HDFC Bank A/c xx1234 on 28-10-26 from ramesh@okaxis (UPI Ref No 430212345679) Avl bal:INR 12,345.00")!!; assertEquals(560.0, c.amt, 0.001); assertEquals("430212345679", c.utr); assertEquals("ramesh@okaxis", c.from) }
    @Test fun axis() { val c = Parser.parse("INR 99.50 credited to A/c no. XX1234 on 28-10-26 at 13:20:11 IST. Info- UPI/P2M/430212345681/RAMESH. Avl Bal- INR 5000.00 - Axis Bank")!!; assertEquals(99.5, c.amt, 0.001); assertEquals("430212345681", c.utr) }
    @Test fun debitIgnored() { assertNull(Parser.parse("Your a/c XX1234 debited INR 500.00 on 28-10-26 UPI ref 430212345684 -PNB")) }
    @Test fun otpIgnored() { assertNull(Parser.parse("123456 is your OTP for UPI. Do not share.")) }
}
