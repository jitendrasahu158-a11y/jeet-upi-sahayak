package com.jeet.upi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject

/**
 * 📩 SMS आते ही: बैंक का "पैसा आया" UPI संदेश हो तो रकम + UTR कतार में डालो और ERP को भेजो।
 * On every SMS: if it is a bank UPI credit, queue amount + UTR and send it to the ERP.
 * (ऐप बंद हो तब भी चलता है / runs even when the app is closed)
 */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = try { Telephony.Sms.Intents.getMessagesFromIntent(intent) } catch (e: Exception) { null } ?: return
        // एक SMS कई टुकड़ों में आता है — भेजने वाले के हिसाब से जोड़ो / join multipart messages per sender
        val bySender = LinkedHashMap<String, StringBuilder>()
        var ts = System.currentTimeMillis()
        for (m in msgs) {
            if (m == null) continue
            val from = m.originatingAddress ?: ""
            bySender.getOrPut(from) { StringBuilder() }.append(m.messageBody ?: "")
            if (m.timestampMillis > 0) ts = m.timestampMillis
        }
        var any = false
        for ((sender, body) in bySender) {
            // बैंक के संदेश अक्षर वाले नाम से आते हैं (जैसे VM-SBIUPI) — मोबाइल नंबर वाले SMS छोड़ो (नकली संदेश से बचाव)
            // banks send from alphanumeric senders; skip plain phone numbers (guards against fake SMS)
            if (Regex("""^\+?\d{6,}$""").matches(sender.trim())) continue
            val cr = Parser.parse(body.toString()) ?: continue
            val o = JSONObject()
                .put("id", "u" + ts + (100 + (Math.random() * 899).toInt()))
                .put("amt", cr.amt).put("utr", cr.utr).put("from", cr.from).put("bank", cr.bank)
                .put("at", ts).put("sender", sender)
            Store.enqueue(context, o)
            any = true
        }
        if (!any || !Store.paired(context)) return
        val pending = goAsync()
        Thread {
            try { Sender.flush(context.applicationContext) } catch (e: Exception) { } finally { pending.finish() }
        }.start()
    }
}
