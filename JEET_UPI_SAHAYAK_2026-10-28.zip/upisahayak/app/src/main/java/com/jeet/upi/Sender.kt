package com.jeet.upi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * ☁️ कतार के पेमेंट ERP के Firebase में भेजना: PUT {db}/upiIn/{चाबी}/{id}.json — चाबी ही इजाज़त है।
 * Sends queued credits to the shop's Firebase; the pairing key is the permission (Rules check upiDev/{key}).
 */
object Sender {
    /** @return कितने भेजे / how many were sent */
    @Synchronized fun flush(c: Context): Int {
        if (!Store.paired(c)) return 0
        val db = Store.db(c); val key = Store.key(c)
        val q = Store.queue(c)
        if (q.length() == 0) return 0
        val left = JSONArray()
        var sent = 0
        for (i in 0 until q.length()) {
            val o = q.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val body = JSONObject()
                .put("amt", o.optDouble("amt"))
                .put("at", o.optLong("at"))
                .put("utr", o.optString("utr"))
                .put("from", o.optString("from"))
                .put("bank", o.optString("bank"))
            val code = put("$db/upiIn/$key/$id.json", body.toString())
            if (code in 200..299) {
                sent++
                Store.addRecent(c, o.put("ok", true))
            } else if (code == 401 || code == 403) {
                // चाबी हटाई गई / Rules नहीं — कतार में रखो / key removed or rules missing — keep it
                o.put("err", "ERP ने मना किया ($code) — ERP में फ़ोन दोबारा जोड़ें / Rules Publish करें")
                left.put(o)
            } else {
                o.put("err", if (code < 0) "इंटरनेट नहीं" else "भेजने में दिक्कत ($code)")
                left.put(o)
            }
        }
        Store.setQueue(c, left)
        return sent
    }

    private fun put(url: String, json: String): Int {
        var con: HttpURLConnection? = null
        return try {
            con = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "PUT"
                connectTimeout = 15000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            con.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            con.responseCode
        } catch (e: Exception) {
            -1
        } finally {
            try { con?.disconnect() } catch (e: Exception) { }
        }
    }
}
