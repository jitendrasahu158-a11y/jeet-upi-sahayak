package com.jeet.upi

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 📲 JEET UPI सहायक — दुकान के फ़ोन में। बैंक का "पैसा आया" SMS पढ़कर रकम + UTR ERP को भेजता है,
 * ERP उसी रकम के UPI बिल पर अपने-आप चढ़ा देता है। यहाँ सिर्फ़: ERP से जोड़ना, अनुमति, बैटरी, हाल के पेमेंट।
 * Shop-phone helper: relays bank credit SMS to the ERP. This screen: pairing, permission, battery, recent list.
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    private val GREEN = Color.parseColor("#0F766E")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); render(); flushInBackground() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.parseColor("#111827")) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(s: String, bg: Int = GREEN, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE); setBackgroundColor(bg)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun card(color: String, vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor(color)); setPadding(dp(12), dp(10), dp(12), dp(12))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) }
        views.forEach { addView(it) }
    }

    private fun hasSms() = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    private fun batteryOk(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun render() {
        root.removeAllViews()
        root.addView(text("📲 JEET UPI सहायक", 22f, true, GREEN))
        root.addView(text("बैंक का \"पैसा आया\" UPI SMS आते ही रकम और UTR आपकी दुकान के ERP को भेजता है। ERP उसी रकम के UPI बिल पर अपने-आप चढ़ा देता है। SMS का बाकी कुछ नहीं भेजा जाता — सिर्फ़ रकम, UTR, भेजने वाले का UPI-नाम।", 14f, color = Color.parseColor("#475569")))

        // 1) जोड़ना / pairing
        if (Store.paired(this)) {
            root.addView(card("#ECFDF5",
                text("✅ जुड़ा है: " + Store.shop(this).ifBlank { "दुकान" }, 16f, true),
                button("जोड़ी हटाएँ", Color.parseColor("#B91C1C")) {
                    Store.unpair(this); toast("जोड़ी हटाई"); render()
                }))
        } else {
            val et = EditText(this).apply {
                hint = "JEETUPI|https://…|…"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 2; textSize = 13f
            }
            root.addView(card("#FFF7ED",
                text("1) ERP से जोड़ें", 17f, true),
                text("ERP ▸ 🩺 हिसाब जाँच ▸ UPI पेमेंट-मिलान ▸ \"फ़ोन जोड़ने का कोड\" कॉपी करके यहाँ चिपकाएँ।", 14f),
                et,
                button("📋 कॉपी किया कोड चिपकाएँ", Color.parseColor("#334155")) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    et.setText(cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: "")
                },
                button("🔗 जोड़ें") {
                    val err = Store.pair(this, et.text.toString())
                    if (err != null) toast(err) else { toast("✅ जुड़ गया"); render(); flushInBackground() }
                }))
        }

        // 2) SMS अनुमति / permission
        root.addView(card(if (hasSms()) "#ECFDF5" else "#FEF2F2",
            text(if (hasSms()) "✅ SMS पढ़ने की अनुमति है" else "2) SMS पढ़ने की अनुमति दें", 16f, true),
            *(if (hasSms()) emptyArray() else arrayOf<View>(
                text("सिर्फ़ बैंक के \"पैसा आया\" संदेश पहचाने जाते हैं; OTP या निजी संदेश कहीं नहीं जाते।", 14f),
                button("अनुमति दें") { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 7) }))))

        // 3) बैटरी / battery
        root.addView(card(if (batteryOk()) "#ECFDF5" else "#FEF2F2",
            text(if (batteryOk()) "✅ बैटरी-बचत से छूट मिली है" else "3) बैटरी-बचत से छूट दें", 16f, true),
            *(if (batteryOk()) emptyArray() else arrayOf<View>(
                text("नहीं तो फ़ोन कुछ देर बाद ऐप रोक देता है और पेमेंट देर से पहुँचते हैं। Xiaomi/Vivo/Oppo में \"Autostart\" भी चालू करें।", 14f),
                button("छूट दें") { askBattery() }))))

        // 4) कतार और हाल के पेमेंट / queue + recent
        val q = Store.queue(this)
        if (q.length() > 0) {
            val v = card("#FEF3C7", text("⏳ " + q.length() + " पेमेंट अभी ERP को नहीं गए", 16f, true))
            val e = q.optJSONObject(q.length() - 1)?.optString("err", "") ?: ""
            if (e.isNotBlank()) v.addView(text(e, 13f))
            v.addView(button("🔄 अभी भेजें") { flushInBackground(true) })
            root.addView(v)
        }
        val r = Store.recent(this)
        val list = card("#F8FAFC", text("हाल के पेमेंट (ERP को भेजे)", 16f, true))
        if (r.length() == 0) list.addView(text("अभी कोई नहीं — UPI से पैसा आते ही यहाँ दिखेगा।", 14f, color = Color.parseColor("#64748B")))
        val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale("en", "IN"))
        for (i in 0 until minOf(r.length(), 20)) {
            val o = r.optJSONObject(i) ?: continue
            list.addView(text("₹" + fmtAmt(o.optDouble("amt")) + " · " + fmt.format(Date(o.optLong("at"))) +
                (if (o.optString("utr").isNotBlank()) " · UTR " + o.optString("utr") else "") +
                (if (o.optString("from").isNotBlank()) "\n" + o.optString("from") else ""), 14f))
        }
        root.addView(list)

        // 5) जाँच / self-test
        val tet = EditText(this).apply { hint = "बैंक का कोई पुराना \"पैसा आया\" SMS यहाँ चिपकाकर जाँचें"; textSize = 13f; minLines = 2 }
        val out = text("", 14f)
        root.addView(card("#F1F5F9", text("🧪 जाँचें कि आपके बैंक का SMS पहचाना जाता है", 15f, true), tet,
            button("पढ़कर देखें (कुछ नहीं भेजेगा)", Color.parseColor("#334155")) {
                val c = Parser.parse(tet.text.toString())
                out.text = if (c == null) "❌ नहीं पहचाना — यह SMS ERP वाले को भेजें ताकि फ़ॉर्मेट जोड़ा जाए" else "✅ ₹" + fmtAmt(c.amt) + (if (c.utr.isNotBlank()) " · UTR " + c.utr else " · UTR नहीं मिला") + (if (c.from.isNotBlank()) " · " + c.from else "") + (if (c.bank.isNotBlank()) " · " + c.bank else "")
            }, out))
        root.addView(text("वर्ज़न 1.0", 12f, color = Color.parseColor("#94A3B8")).apply { gravity = Gravity.CENTER })
    }

    private fun fmtAmt(v: Double): String = if (v == Math.floor(v)) v.toLong().toString() else String.format(Locale.US, "%.2f", v)

    private fun askBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { toast("सेटिंग ▸ बैटरी में जाकर इस ऐप को \"Unrestricted\" करें") }
        }
    }

    private fun flushInBackground(showResult: Boolean = false) {
        if (!Store.paired(this)) return
        Thread {
            val n = try { Sender.flush(applicationContext) } catch (e: Exception) { 0 }
            ui.post { if (showResult) toast(if (n > 0) "✅ $n भेजे" else "अभी नहीं जा सके — इंटरनेट देखें"); render() }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    @Suppress("unused") private fun dbg(o: JSONObject) = o.toString()
}
