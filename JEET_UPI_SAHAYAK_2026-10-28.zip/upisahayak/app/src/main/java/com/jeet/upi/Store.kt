package com.jeet.upi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 💾 जोड़ी (ERP का पता + चाबी), भेजने की कतार और हाल के पेमेंट — फ़ोन में ही।
 * Pairing, the outbound queue and recent credits, kept on the phone.
 */
object Store {
    private const val P = "upi_sahayak"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun db(c: Context): String = sp(c).getString("db", "") ?: ""
    fun key(c: Context): String = sp(c).getString("key", "") ?: ""
    fun shop(c: Context): String = sp(c).getString("shop", "") ?: ""
    fun paired(c: Context) = db(c).isNotBlank() && key(c).isNotBlank()

    /** "JEETUPI|https://….firebaseio.com|<चाबी>|<दुकान>" */
    fun pair(c: Context, code: String): String? {
        val p = code.trim().split("|")
        if (p.size < 3 || p[0] != "JEETUPI") return "कोड सही नहीं — ERP ▸ 📲 UPI पेमेंट-मिलान से पूरा कोड कॉपी करें"
        val db = p[1].trim().trimEnd('/')
        val key = p[2].trim()
        if (!db.startsWith("https://") || !Regex("^[0-9a-f]{32}$").matches(key)) return "कोड अधूरा है — दोबारा कॉपी करें"
        sp(c).edit().putString("db", db).putString("key", key).putString("shop", p.getOrNull(3) ?: "").apply()
        return null
    }

    fun unpair(c: Context) { sp(c).edit().remove("db").remove("key").remove("shop").apply() }

    @Synchronized fun queue(c: Context): JSONArray = try { JSONArray(sp(c).getString("q", "[]")) } catch (e: Exception) { JSONArray() }
    @Synchronized fun setQueue(c: Context, a: JSONArray) { sp(c).edit().putString("q", a.toString()).apply() }

    @Synchronized fun enqueue(c: Context, o: JSONObject) {
        val q = queue(c)
        // वही UTR दोबारा नहीं / never queue the same UTR twice
        val utr = o.optString("utr", "")
        for (i in 0 until q.length()) if (utr.isNotEmpty() && q.optJSONObject(i)?.optString("utr") == utr) return
        q.put(o)
        while (q.length() > 300) q.remove(0)
        setQueue(c, q)
    }

    @Synchronized fun recent(c: Context): JSONArray = try { JSONArray(sp(c).getString("r", "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized fun addRecent(c: Context, o: JSONObject) {
        val r = recent(c)
        val n = JSONArray().put(o)
        for (i in 0 until minOf(r.length(), 29)) n.put(r.get(i))
        sp(c).edit().putString("r", n.toString()).apply()
    }
}
