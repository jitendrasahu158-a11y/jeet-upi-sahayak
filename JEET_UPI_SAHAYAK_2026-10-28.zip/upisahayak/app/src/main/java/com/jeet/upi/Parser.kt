package com.jeet.upi

/**
 * 🔎 बैंक का "पैसा आया" UPI SMS पढ़ना — ERP (jeet-upimatch.js) के parseSms जैसे ही नियम।
 * Parses a bank credit (UPI) SMS into amount + UTR + payer; same rules as the ERP's parseSms.
 */
data class Credit(val amt: Double, val utr: String, val from: String, val bank: String)

object Parser {
    private val OTP = Regex("""\botp\b|one time password|verification code""", RegexOption.IGNORE_CASE)
    private val CREDIT = Regex("""credited|received|deposited|has been added|money received|cr\.? (?:by|to|with)|\bcr\b|जमा""", RegexOption.IGNORE_CASE)
    private val DEBIT = Regex("""debited|withdrawn|spent|sent to|paid to|\bdr\b|नामे""", RegexOption.IGNORE_CASE)
    private val CREDIT_OK = Regex("""credited to (?:your|a/c)|received""", RegexOption.IGNORE_CASE)
    private val UPIISH = Regex("""upi|imps|\b\d{12}\b""", RegexOption.IGNORE_CASE)
    private val AMT = Regex("""(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.\d{1,2})?)""", RegexOption.IGNORE_CASE)
    private val UTR1 = Regex("""(?:utr|rrn|ref(?:erence)?\.?\s*(?:no|number|id)?|refno|txn\s*(?:id|no)?|upi\s*(?:ref|txn)?)[\s:.#/-]*(?:no\.?)?[\s:.#/-]*(\d{12})""", RegexOption.IGNORE_CASE)
    private val UTR2 = Regex("""upi/(?:p2[ma]/)?(\d{12})""", RegexOption.IGNORE_CASE)
    private val UTR3 = Regex("""\b(\d{12})\b""")
    private val VPA = Regex("""([a-z0-9][a-z0-9.\-_]{1,60}@[a-z]{2,20})""", RegexOption.IGNORE_CASE)
    private val NAME = Regex("""(?:from|by)\s+([A-Za-z][A-Za-z .]{2,40}?)(?:\s+(?:on|via|ref|upi|\(|\.|-)|$)""", RegexOption.IGNORE_CASE)
    private val NOTNAME = Regex("""a/c|account|upi|imps""", RegexOption.IGNORE_CASE)
    private val BANK = Regex("""\b(SBI|HDFC|ICICI|AXIS|KOTAK|PNB|BOB|BARODA|CANARA|UNION|IDBI|YES|INDUSIND|IDFC|FEDERAL|INDIAN BANK|BOI|CENTRAL|UCO|IPPB|AIRTEL|PAYTM|FINO|AU)\b""", RegexOption.IGNORE_CASE)

    fun parse(raw: String?): Credit? {
        val t = (raw ?: "").replace(Regex("""\s+"""), " ").trim()
        if (t.isEmpty()) return null
        if (OTP.containsMatchIn(t)) return null
        val credit = CREDIT.containsMatchIn(t)
        val debit = DEBIT.containsMatchIn(t)
        if (!credit || (debit && !CREDIT_OK.containsMatchIn(t))) return null
        if (!UPIISH.containsMatchIn(t)) return null
        var amt = 0.0
        for (m in AMT.findAll(t)) {
            val before = t.substring(maxOf(0, m.range.first - 14), m.range.first).lowercase()
            if (before.contains("bal") || before.contains("limit")) continue
            amt = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: 0.0
            break
        }
        if (amt <= 0.0) return null
        val utr = (UTR1.find(t) ?: UTR2.find(t) ?: UTR3.find(t))?.groupValues?.get(1) ?: ""
        var from = VPA.find(t)?.groupValues?.get(1) ?: ""
        if (from.isEmpty()) {
            val n = NAME.find(t)?.groupValues?.get(1)?.trim() ?: ""
            if (n.isNotEmpty() && !NOTNAME.containsMatchIn(n)) from = n
        }
        val bank = (BANK.find(t)?.groupValues?.get(1) ?: "").uppercase()
        return Credit(Math.round(amt * 100) / 100.0, utr, from.take(80), bank.take(30))
    }
}
